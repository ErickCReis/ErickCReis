# Shipping Astro From A Bun Server

## Core Idea

Explain how the project builds static Astro output and serves it from the same Bun/Elysia server that owns the live API.

The focus is deployment shape, not generic Docker basics.

## Chronology

- `2026-03-01`: build switched to a Bun single-file executable.
- `2026-03-07`: dist assets were added to server routes.
- `2026-03-07`: route generation switched from embedded payloads to file paths.
- `2026-03-07`: duplicate routes and cache-control rules were added.

## Libraries And Integrations

- Bun build and compile.
- Astro static output.
- Elysia `file`.
- Bun macros.
- Docker multi-stage build.

## Story Beats

- Start with the deployment requirement: one production server should serve both static pages and live endpoints.
- Show the build sequence:
  - Astro builds `dist`,
  - Bun compiles `server/index.ts`,
  - Docker copies the dist files, binary, and migrations.
- Explain the route generator:
  - walks `dist`,
  - maps `index.html` to clean routes,
  - fails on duplicate routes,
  - assigns cache-control by asset type.
- Explain why this keeps Astro static while Elysia owns runtime features.

## Code Anchors

- `package.json`
- `Dockerfile`
- `server/dist-assets.macro.ts`
- `server/dist-assets.ts`
- `server/index.ts`

## Open Questions

- Should this include the exact production command output?
- Should the post mention the earlier embedded-assets version?
- Should route conflict examples be shown?
