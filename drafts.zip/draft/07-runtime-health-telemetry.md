# Health Telemetry From The Real Runtime

## Core Idea

Explain how the site measures itself and its host: CPU, memory, cgroup limits, battery status, uptime, and email alerts.

The theme is "telemetry should match where the app actually runs."

## Chronology

- `2026-03-03`: cgroup-aware system stats were added.
- `2026-03-03`: uptime display started.
- `2026-03-04`: optional battery telemetry was added.
- `2026-03-24`: uptime moved to UptimeRobot polling.
- `2026-04-09`: cron battery alerts via email were added.
- `2026-05-20`: uptime handling was hardened after poll failures and outages.

## Libraries And Integrations

- Node `os`.
- Linux cgroup files.
- UptimeRobot API.
- `@elysiajs/cron`.
- Resend email API.
- Bun file APIs.

## Story Beats

- Start with the problem: container stats are not always the same as host stats.
- Explain cgroup memory and CPU limits.
- Explain battery telemetry as optional host data mounted into the container.
- Explain uptime as an external truth source rather than a local process counter.
- Explain battery alerts as a tiny cron integration using the same battery reader.
- Close with the difference between dashboard telemetry and actionable alerts.

## Code Anchors

- `server/stats/system.ts`
- `server/stats/server.ts`
- `server/stats/uptime.ts`
- `server/lib/battery.ts`
- `server/cron/battery-alert.ts`
- `docker-compose.yml`

## Open Questions

- Should this be more Linux/container focused?
- Should UptimeRobot get its own post, or stay in this runtime health post?
- Should battery alerts be treated as a playful aside or a serious operational detail?
