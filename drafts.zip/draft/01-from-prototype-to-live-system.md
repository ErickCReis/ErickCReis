# Rewriting My Portfolio For Self-Hosting

## Core Idea

This first post should explain the architectural pivot through the self-hosting experiment:

I had a spare laptop, I was testing self-hosted deployment options, and I wanted this portfolio to become a small real service instead of only a static page. Dokploy can appear naturally in the content, but the main story is self-hosting and learning the operational shape of running my own app.

Main thesis: a single server can handle more than people usually assume, especially for a small personal project. The tradeoff is simple: more control and fewer platform integrations, but more direct responsibility for runtime behavior.

Keep it short, technical, and concrete. Target: 700-900 words.

## Working Summary

The early version of the project explored a platform-style setup: a monorepo, separate web/server apps, Cloudflare-oriented deployment pieces, auth, RPC, and a cursor websocket experiment.

That was useful, and the Cloudflare direction still fits many other projects. I like Cloudflare and use it often. For this project, though, the goal changed: use the site as a self-hosting playground. I had a spare laptop available as a learning machine, Dokploy was one of the deployment surfaces I wanted to test, and the app needed a shape that would be easy to build, containerize, run, observe, and iterate on from that environment.

The moment that made the experiment feel concrete was running Cloudflared from the Dokploy setup and reaching the laptop through `erickr.dev` over a tunnel. At that point the laptop was not just a local machine anymore; it was serving a real domain.

The result was the current shape:

- Astro builds the mostly static site.
- Solid hydrates only the live parts.
- Elysia owns runtime APIs, SSE, websockets, and internal routes.
- Bun builds and runs the server.
- Docker packages the app for the self-hosted machine.
- The same service exposes its own telemetry, making the deployment visible.

The main simplification was role architecture: instead of splitting responsibilities across several platform-specific services, this version uses one server process as the owner of static files, API routes, live connections, local data, files, and internal jobs.

That is the interesting self-hosting difference: persistence and files are not special products anymore. They are local resources the app can own directly. The downside is that websocket state, monitoring, and runtime process behavior also become my responsibility.

The post should end by saying that the rest of the series explains the small integrations that grew from this base.

## Chronology

- `2025-06-21`: initial Turbo monorepo with server and web apps.
- `2025-06-21`: Cloudflare-oriented deployment setup with Alchemy/Wrangler.
- `2025-06-21`: auth integration.
- `2025-06-23`: cursor websocket experiment.
- `2026-02-27`: rewrite into the current Bun/Astro/Elysia app.
- `2026-03-01`: build moved toward a Bun single-file executable.
- `2026-03-07`: Astro dist assets became server-owned routes.
- Later posts: telemetry, content tracking, i18n, token usage, presence.

## Libraries And Integrations

Old exploration:

- Turbo
- Hono
- oRPC
- better-auth
- Drizzle
- Alchemy
- Wrangler
- Cloudflare Durable Objects
- D1

Current self-hosting shape:

- Bun
- Astro
- Solid
- Elysia
- Eden Treaty
- Valibot
- Docker / Docker Compose
- Dokploy as the self-hosting/deployment experiment
- Cloudflared tunnel for exposing the laptop through the domain

## Simple Graph 1: Architecture Pivot

```mermaid
flowchart LR
  A["Platform-oriented prototype"] --> B["Self-hosting experiment"]
  B --> C["Spare laptop"]
  B --> D["Dokploy"]
  D --> E["Cloudflared tunnel"]
  C --> F["Dockerized app"]
  D --> F
  E --> G["erickr.dev"]
  G --> F
  F --> H["Bun + Elysia server"]
  H --> I["Astro static pages"]
  H --> J["Live APIs"]
  H --> K["Telemetry"]
```

## Simple Graph 2: Runtime Shape

```mermaid
flowchart TB
  Repo["Git repo"] --> Build["Build image"]
  Build --> Runtime["Container on spare laptop"]

  Domain["erickr.dev"] --> Tunnel["Cloudflared tunnel"]
  Tunnel --> Runtime

  Runtime --> Static["Astro dist"]
  Runtime --> Api["Elysia routes"]
  Runtime --> Live["SSE + WebSocket"]
  Runtime --> Data["SQLite / JSON data"]

  Api --> Stats["Stats modules"]
  Live --> Cursor["Cursor presence"]
  Stats --> UI["Solid telemetry panels"]
```

## Draft Structure

### 1. The Reason For The Rewrite

Open with the spare laptop and self-hosting experiment. The laptop is a learning machine used for experiments like local LLMs, media services, and remote development, but keep those as one sentence of context. The post should focus on this site's deployment shape.

The site was a good candidate because it is small enough to self-host but complex enough to exercise the important pieces: static pages, runtime APIs, websockets, background polling, local data, and deployable containers.

Avoid framing the rewrite as "the old stack was bad." Frame it as "the project goal changed."

### 2. What The First Version Taught Me

Mention the old stack briefly and positively:

- a monorepo made exploration easy,
- Hono/oRPC/auth/Drizzle were useful pieces,
- Cloudflare/Durable Objects made the first cursor experiment possible,
- Cloudflare is still a platform I like and use for other work,
- but this project became a deliberate self-hosting learning exercise.

Keep this section short. It is context, not the main post.

Important nuance: the goal was not cost savings. At this traffic volume, Cloudflare was effectively free too. The value was learning the self-hosted deployment path.

### 3. The Shape I Wanted For Self-Hosting

List the technical requirements:

- one container to deploy,
- one server process to observe,
- static files and runtime routes in the same service,
- easy local data directory,
- direct control over files and persistence,
- clear environment variables,
- enough live behavior to make the deployment interesting.

This section should connect directly to public repo files such as `package.json`, `Dockerfile`, `docker-compose.yml`, and `server/index.ts`. Show the build script and the minimal runtime image, because that is the clearest concrete example of the self-hosted shape.

This is also where the post should mention the strongest design pressure: simplifying deploy and infrastructure-as-code complexity by making the app a single server instead of several platform-specific moving parts.

The platform constraints that mattered most were runtime shape and websocket setup. Workers are powerful, but the app started to feel like it needed platform glue for things that are straightforward in a normal server process.

### 4. The Current Base

Explain the small stack:

- Astro for static output,
- Solid for hydrated islands,
- Elysia for routes, SSE, and websockets,
- Bun for runtime and build,
- shared TypeScript contracts for client/server edges.

Keep it practical. No broad framework comparison.

The takeaway should be concrete: for this kind of project, one server can own a lot of behavior without becoming a distributed system.

Bun is part of the argument here. It lets the project use the same runtime for scripts, build steps, and the server process. Avoid traffic claims in the final article; the useful point is that Bun can compile the server into a raw executable that the runtime image can run without installing app dependencies.

Potential repo snippets:

- `package.json`: show the `build` script that runs Astro and compiles `server/index.ts` into `myserver`.
- `Dockerfile`: show the build stage and minimal runtime stage with `CMD ["./myserver"]`.
- `server/index.ts`: link to it as the server entry, but do not show a full snippet in this post.

Avoid going deep on static asset routing here. Mention that the Astro build output is served by the same Elysia app, then leave the route generation details for the next deployment-focused post.

### 5. What Still Needs Work

Add one honest caveat before the closing: the realtime layer is not as clean as it should be yet.

Managing state and monitoring connections is more manual in the current setup than it was with Cloudflare Durable Objects plus D1. That does not invalidate the self-hosting approach, but it points to an area that needs a better local abstraction.

This is the clearest tradeoff in the article:

- Durable Objects gave a natural place for realtime state.
- D1 gave a managed persistence story.
- The self-hosted server gives more control, but I need better local abstractions for connection lifecycle, observability, and state cleanup.

### 6. Why This Became A Series

Close with the idea that the self-hosted base created room for small integrations:

- live cursor presence,
- system and uptime telemetry,
- Spotify and GitHub panels,
- content view tracking,
- custom i18n,
- token usage sync.

Each one is small enough to explain on its own.

## Narrative Spine

1. I already had a spare laptop that I used as a learning machine.
2. I wanted to explore self-hosting with tools that matched the stack I enjoy.
3. The project had enough moving parts to be a useful test: static pages, runtime routes, live connections, jobs, and data.
4. The concrete moment was reaching the laptop from `erickr.dev` through a Cloudflared tunnel managed inside the self-hosted setup.
5. That changed the architecture goal: optimize for one deployable server instead of platform-specific pieces.
6. The app became simpler because files, data, jobs, static assets, APIs, and live routes can all live behind one process.
7. The current stack is not a final answer, but it proves the main point: a single server can carry a lot for a small personal app.

## Code Anchors

- `server/index.ts`
- `package.json`
- `Dockerfile`
- `docker-compose.yml`
- `server/dist-assets.ts`
- `server/dist-assets.macro.ts`
- `astro.config.mjs`
- `web/islands/home-live-overlay.tsx`

Historical context:

- `d9a0074`: initial project
- `f1a45ef`: cursor websocket experiment
- `cce5406`: rewrite
- `9aa36c7`: Bun executable build
- `45e02a7`: dist assets served by the app

## Resolved Direction

- Do not make Dokploy the headline. It belongs in the post as the tool used during the self-hosting experiment.
- Show or link to concrete repo files when they clarify the deployment shape.
- Mermaid diagrams are wanted, but the final blog needs static rendering at build time.
- Summarize the old Cloudflare version briefly and positively. The move was not rejection of Cloudflare; it was a deliberate deploy strategy change to learn self-hosting.
- The spare laptop is a learning machine, but local LLMs, media server, and remote dev can stay as brief context or later-post material.
- Dokploy was interesting because the stack felt aligned, it was easy to use, and it was already familiar from a side project.
- Cost is not the main argument here; Cloudflare was also effectively free at current volume.
- The first concrete success moment was exposing the laptop through `erickr.dev` with Cloudflared tunnels.
- The main constraint was reducing IaC/deploy complexity and escaping worker-specific limits for this experiment.
- The most important platform limits were runtime constraints and websocket setup complexity.
- The biggest simplification was using one unique server.
- Self-hosting makes files and persistence feel direct instead of productized.
- Bun should be mentioned as a practical part of the single-server story, specifically because the build creates a raw executable for the runtime image.
- The caveat is realtime state: connection management and monitoring still need a better abstraction.
- The final article should show snippets from `package.json` and `Dockerfile`; only link to `server/index.ts`.
- Static asset handling is relevant, but detailed route generation can be saved for the deployment/static-assets post.
- Avoid "Bun can handle a lot of traffic" claims.
- End with an architecture checklist, not a code recipe.

## Possible Final Title Options

- Rewriting My Portfolio For Self-Hosting
- A Small Live Site For A Spare Laptop
- Why This Portfolio Runs Like A Tiny Service
- Learning Self-Hosting Through My Portfolio

## Audience

Developers curious about self-hosting and deployment tools. The post should be useful even if the reader does not care about this specific portfolio.

## Final Writing Plan

- Show the `package.json` build script because it explains the two build products: Astro `dist` and Bun's compiled `myserver`.
- Show the Dockerfile's build/runtime split because it makes the minimal runtime image concrete.
- Link to `server/index.ts` as the server entry, but do not spend the article on route composition.
- Mention static file handling as a reason the single-server setup works, then defer the details to a later post.
- Close with an architecture checklist readers can apply to small self-hosted apps.
