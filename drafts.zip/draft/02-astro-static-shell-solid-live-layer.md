# Astro As The Static Shell, Solid As The Live Layer

## Core Idea

Explain how the site uses Astro for static structure and Solid only for parts that need client-side reactivity.

This is the "static where possible, live where useful" post.

## Chronology

- `2026-02-27`: rewrite created the Astro and Solid base.
- `2026-02-28`: layout and content structure evolved.
- `2026-03-22`: homepage and live overlay were refined.

## Libraries And Integrations

- Astro pages and layouts.
- `@astrojs/solid-js` for islands.
- Astro transitions and fonts.
- Tailwind CSS v4 through `@tailwindcss/vite`.
- Solid signals for UI state.

## Story Beats

- Start with the constraint: most portfolio content should be static.
- Show how Astro owns page structure, metadata, routing, and content rendering.
- Show how Solid enters only at island boundaries like `HomeLiveOverlay`.
- Explain `client:only="solid-js"` as a clear hydration decision.
- Talk about why this keeps the homepage lightweight while still allowing live telemetry and cursors.

## Code Anchors

- `astro.config.mjs`
- `web/layouts/base-layout.astro`
- `web/pages/[...locale]/index.astro`
- `web/islands/home-live-overlay.tsx`
- `web/components/telemetry-backdrop.tsx`

## Open Questions

- Should this post include bundle/performance details, or stay architectural?
- Should this introduce Astro content collections now or leave that for the blog-layer post?
- Should the post compare Solid islands with React islands, or avoid framework comparison?
