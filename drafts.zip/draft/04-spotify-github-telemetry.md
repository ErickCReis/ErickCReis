# Personal Telemetry From Spotify And GitHub

## Core Idea

Explain how external APIs become live panels on the portfolio: Spotify now-playing state and GitHub contribution stats.

The theme is "personal APIs as product data."

## Chronology

- `2026-02-28`: Spotify playback information was added to telemetry.
- `2026-02-28`: GitHub commit tracking was added.
- `2026-03-26`: GitHub commit dates were adjusted for local midnight.
- `2026-06-17`: GitHub stats and charts were adjusted alongside token charts.

## Libraries And Integrations

- Spotify token refresh flow.
- Spotify currently-playing endpoint.
- GitHub GraphQL API.
- Bun `fetch`.
- Valibot validation for cached data.
- Solid panels and chart components.

## Story Beats

- Start with the idea that the portfolio can show current context, not just static claims.
- Spotify section:
  - refresh token to access token,
  - poll faster while music is playing,
  - back off on rate limits,
  - expose safe empty states.
- GitHub section:
  - one GraphQL query for the year-to-date contribution calendar,
  - derive today, month, year, and 30-day series locally,
  - cache responses to avoid waste.
- Connect both to the shared stat module pattern.

## Code Anchors

- `server/stats/spotify.ts`
- `server/stats/github.ts`
- `shared/stats/spotify.ts`
- `shared/stats/github.ts`
- `web/stats/spotify/panel.tsx`
- `web/stats/github/panel.tsx`

## Open Questions

- Should this be one post or split into Spotify and GitHub?
- Should API rate limiting be a central section?
- Should the post include notes about which data is intentionally not stored?
