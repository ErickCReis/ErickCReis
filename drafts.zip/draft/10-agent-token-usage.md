# Agent Token Usage As A First-Class Stat

## Core Idea

Explain how local agent session logs became a synced telemetry source alongside system, Spotify, GitHub, and uptime stats.

This is the newest and most personal integration in the series.

## Chronology

- `2026-02-28`: first Codex usage telemetry panel was added.
- `2026-03-08`: Codex usage was merged by source with dated daily entries.
- `2026-04-01`: configured timezone was used for daily stats.
- `2026-04-25`: windowing and freshness handling were fixed.
- `2026-06-02`: Codex stats were generalized into token usage sync.
- `2026-06-17`: Claude token usage and provider charts were added.

## Libraries And Integrations

- Bun filesystem APIs.
- JSONL session parsing.
- Valibot payload validation.
- Elysia internal sync endpoint.
- Bearer-token protected ingestion.
- Solid stacked bar chart.

## Story Beats

- Start with the question: can the site show how much work the agents are doing?
- Explain the split:
  - local script reads provider-specific session files,
  - server accepts normalized sync payloads,
  - stat module aggregates providers and date windows,
  - UI renders provider totals.
- Show provider adapters:
  - Codex token count events,
  - Pi assistant message usage,
  - Claude assistant messages with cache tokens.
- Explain source ids and why multiple machines/providers need stable merging.
- Explain stale handling so the UI can show when sync has stopped.
- End with what this suggests for future personal dashboards.

## Code Anchors

- `scripts/token-usage-sync.ts`
- `server/internal/routes.ts`
- `server/stats/token-usage.ts`
- `shared/stats/token-usage.ts`
- `shared/stats/token-usage.transport.ts`
- `web/stats/token-usage/store.ts`
- `web/stats/token-usage/panel.tsx`
- `web/components/bar-chart.tsx`

## Open Questions

- Should this include sample normalized payloads?
- Should provider-specific parsing be explained in separate sections?
- Should the post discuss privacy and what is not uploaded?
