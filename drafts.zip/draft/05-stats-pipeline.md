# The Stats Pipeline

## Core Idea

Explain the reusable telemetry pipeline that powers the panels: stat modules collect data, shared serializers compact it, Elysia streams it, and Solid stores render it.

This is probably the most important technical post in the series.

## Chronology

- `2026-03-02`: telemetry structure was reorganized.
- `2026-03-03`: stats redesign was finished.
- `2026-03-27`: latest stat snapshots were split from history snapshots.
- `2026-03-27`: shared stats transport serialization was added.
- `2026-04-05`: stats stream reconnect behavior was improved.

## Libraries And Integrations

- Elysia route composition.
- Elysia SSE.
- Eden Treaty typed client.
- Valibot shared schemas.
- Solid signals/stores.

## Story Beats

- Start with the UI problem: many panels, each updated at different rates.
- Introduce the `StatModule` shape: `start`, `getLatest`, `getHistory`, `getVersion`.
- Explain why SSE fits the stats stream better than websockets here.
- Explain the compact transport format and why it exists.
- Show how the client first loads history, then subscribes to stream updates.
- Show how each panel remains small because the pipeline does the shared work.

## Code Anchors

- `server/stats/routes.ts`
- `server/stats/history.ts`
- `server/stats/types.ts`
- `shared/stats/transport.ts`
- `web/stats/history.ts`
- `web/stats/stream.ts`
- `web/stats/*/store.ts`

## Open Questions

- Should this include before/after payload examples?
- Should the post explain tuple serialization tradeoffs?
- Should this come before the Spotify/GitHub post so readers understand the stat module shape first?
