# A Small Custom i18n Runtime For Astro

## Core Idea

Explain the custom translation plugin and runtime: collect strings at build time, generate translation catalogs, expose a virtual module, and route localized pages.

The theme is "small custom tooling when the problem is narrower than a full framework."

## Chronology

- `2026-04-03`: locale-aware routing and translation runtime were added.
- `2026-04-03`: telemetry panel labels were refined.
- `2026-04-05`: locale-aware blog slugs and Portuguese posts were added.
- `2026-04-05`: localized blog post slugs were allowed.
- `2026-04-20`: sitemap and SEO metadata were added.

## Libraries And Integrations

- Astro integration hooks.
- Vite virtual modules.
- ESTree parsing through Vite plugin context.
- Type injection for `virtual:translate`.
- Astro static paths.
- SEO alternates and Open Graph locale metadata.

## Story Beats

- Start with the requirement: bilingual UI and blog routes without adding a large i18n framework.
- Explain the `t()` API from the author's perspective.
- Show the plugin side:
  - scan code for static translation strings,
  - hash source strings,
  - generate default and locale catalogs,
  - inject virtual module types.
- Show the runtime side:
  - resolve locale from path or document language,
  - use build catalogs during SSR,
  - use client catalogs in hydrated islands.
- Show localized blog slugs as the content-specific extension.

## Code Anchors

- `plugins/translate-plugin.ts`
- `plugins/translate-runtime.ts`
- `astro.config.mjs`
- `web/i18n/index.ts`
- `web/lib/blog.ts`
- `web/components/locale-switcher.astro`
- `web/layouts/base-layout.astro`

## Open Questions

- Should the post explain hash collisions or keep that out of scope?
- Should generated catalog files be shown?
- Should this compare against existing Astro i18n approaches?
