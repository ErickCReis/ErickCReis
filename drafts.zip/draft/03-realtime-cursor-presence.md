# Realtime Cursor Presence With Tiny Pieces

## Core Idea

Explain the cursor presence feature as a small full-stack integration: browser pointer tracking, a typed websocket, cookie-backed identity, and a Solid rendering layer.

## Chronology

- `2025-06-23`: first cursor websocket experiment using Cloudflare Durable Objects and oRPC.
- `2026-02-27`: cursor presence moved into the rewritten Bun/Elysia system.
- `2026-03-22`: homepage cursor behavior was refined.
- `2026-04-05`: reconnect behavior was improved.

## Libraries And Integrations

- Elysia websocket route.
- Eden Treaty client.
- Valibot schema for cursor payloads.
- Solid signals and effects.
- `@solid-primitives/mouse` for pointer tracking.
- `@solid-primitives/scheduled` for throttling.

## Story Beats

- Start from the visible feature: seeing other cursors on the homepage.
- Break it into small responsibilities:
  - server creates a cursor id,
  - browser tracks pointer position,
  - client throttles websocket sends,
  - server validates and broadcasts payloads,
  - Solid renders local and remote cursors.
- Explain why identity is cookie-backed instead of trusting arbitrary client ids.
- Show the stale cursor cleanup and reconnect logic.
- End with what this feature teaches about small live interactions.

## Code Anchors

- `server/live/routes.ts`
- `shared/cursor.ts`
- `web/lib/api.ts`
- `web/hooks/use-cursor-presence.ts`
- `web/components/cursor-presence-layer.tsx`

## Open Questions

- Should this mention the old Durable Object implementation as a contrast?
- Should the post include diagrams for the websocket message flow?
- Should it explain why cursor updates are not persisted?
