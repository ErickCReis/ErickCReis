# The Blog Layer

## Core Idea

Explain how the project combines static MDX posts with dynamic view counts.

This post should show that the blog itself is also part of the live system.

## Chronology

- `2026-03-22`: blog detail pages and archive metadata were added.
- `2026-03-22`: nested content routes and typography were refined.
- `2026-04-02`: content view tracking and hydration were added.
- `2026-04-02`: routes were refactored and prefixed ids were introduced.
- `2026-04-05`: localized blog slugs were added.

## Libraries And Integrations

- Astro content collections.
- MDX.
- `@tailwindcss/typography`.
- Lucide Astro.
- Drizzle ORM with SQLite.
- Valibot request validation.
- Eden Treaty client.
- Solid islands for hydration.

## Story Beats

- Start with static content as the baseline.
- Explain Astro's content collection and MDX rendering.
- Introduce the dynamic need: view counts on static pages.
- Show the server side:
  - validate slug input,
  - assign visitor cookie,
  - dedupe within 24 hours,
  - update totals transactionally.
- Show the client side:
  - hydrate list counts after page load,
  - register a view only on the post page,
  - wait for visible document before counting.
- Close with why dynamic counters do not require making the whole blog dynamic.

## Code Anchors

- `web/content.config.ts`
- `web/lib/blog.ts`
- `web/pages/[...locale]/content.astro`
- `web/pages/[...locale]/content/[...slug].astro`
- `server/content/routes.ts`
- `server/content/views.ts`
- `server/db/schema.ts`
- `web/islands/post-view-counter.tsx`

## Open Questions

- Should the post include database schema snippets?
- Should it explain why view tracking uses cookies instead of local storage?
- Should it cover privacy expectations around page-view tracking?
